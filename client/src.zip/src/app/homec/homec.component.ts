import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homec',
  templateUrl: './homec.component.html',
  styleUrls: ['./homec.component.css']
})
export class HomecComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
