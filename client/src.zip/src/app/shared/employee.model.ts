export class Employee {
    _id: string;
    name: string;
    position: string;
    office: string;
    salary: number;
    designation:string;
    team:string;
    phone:number;
    email:string;
    cid:string;
    location:string;
}
