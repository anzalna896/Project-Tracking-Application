export class List {
    _id: string;
    title: string;
    lang:string;
    pro:number;
    
}
